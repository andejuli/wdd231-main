document.querySelector('.green').addEventListener('click', () => {
    document.querySelector('.blue').classList.toggle('show');
})